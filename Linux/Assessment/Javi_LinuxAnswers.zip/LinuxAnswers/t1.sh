#!/bin/bash
mkdir directory1
cd directory1
mkdir directory2
cd directory1
mkdir directory3
cd directory3
touch file1
touch file2
mkdir directory4
cd directory4
touch file3 file4 file5 file6
cd ../..
mkdir directory5
cd directory5
touch file7 file8
cd ../..
touch file9
