#!/bin/bash
export PATH="${PATH}:/home/javi/assessment/commands"
cd assessment/commands/
touch fizzbuzz
chmod 777 fizzbuzz
