#!/bin/bash
name="Name: Javier"
email="Email: javialcazafra@gmail.com"
dat3="Date: $(date)"
echo $name > assessment/info
echo $email >> assessment/info
echo $dat3 >> assessment/info
