#!/bin/bash
set +o noclobber
assessment/commands/fizzbuzz > assessment/data/fb/fb_output; echo "$(date): fizzbuzz executed" > assessment/logs/executionlog
