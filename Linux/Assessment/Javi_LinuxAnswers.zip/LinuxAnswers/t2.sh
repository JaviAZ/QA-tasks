#!/bin/bash
mv directory1/ assessment/
mv assessment/directory2/ assessment/commands/
mv assessment/directory3/ assessment/data/
cd assessment/data
mv file1 input
mv file2 output
mv directory4/ fb/
cd fb
mv file3 fb_output
mv file4 fizz
mv file5 buzz
mv file6 fizzbuzz
cd ../..
mv directory5 logs
cd logs
mv file7 errorlog
mv file8 executionlog
cd ../..
mv file9 assessment/info
